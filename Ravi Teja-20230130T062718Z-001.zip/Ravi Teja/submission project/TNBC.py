#### importing the requried libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,confusion_matrix
import seaborn as sns

### load the dataset

data = pd.read_excel("C:/Users/DELL/Desktop/DS_Project_Team_60/TNBC_survival.xlsx")

### 1. Exploratory Data Analysis

data.describe()

#### Business Decision Movement 

data.mean()
data.median()
data.std()
data.var()
data.skew()
data.kurt()

#### Data Visualization

### Histogram

data.hist(figsize = (10,10))

#### Boxplot

data.boxplot(figsize = (10,10))

##### DATA Preprocessing

#### Type Casting

data.dtypes

#### Identifying the duplicates

duplicate = data.duplicated()
sum(duplicate)

#### Missing Values

data.isna()
data.isna().sum()

### For replacing the missing values here using the mean imputation or fillna() 

from sklearn.impute import SimpleImputer

# Mean Imputer 
mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
data["relapse_time"] = pd.DataFrame(mean_imputer.fit_transform(data[["relapse_time"]]))
data["relapse_time"].isna().sum()

mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
data["Outcome_time"] = pd.DataFrame(mean_imputer.fit_transform(data[["Outcome_time"]]))
data["Outcome_time"].isna().sum()

lb = LabelEncoder()

data ["HPE"] = lb.fit_transform(data["HPE"])
data ["Stage"] = lb.fit_transform(data["Stage"])
data ["Surgery"] = lb.fit_transform(data["Surgery"])
data ["Treatmentgivenonrelapse"] = lb.fit_transform(data["Treatmentgivenonrelapse"])
data ["TumorSize"] = lb.fit_transform(data["TumorSize"])
data ["Chemogiveninitially"] = lb.fit_transform(data["Chemogiveninitially"])
data["Survival "] = lb.fit_transform(data["Survival "])

data_f = data
data_f.info()

import pickle

with open("data_f.pickle","wb") as f:
    pickle.dump(data_f,f)

### Outlier Treatment ( here the relapse _time column has the outliers can removed by using the winsorization technique )

IQR = data['relapse_time'].quantile(0.75) - data['relapse_time'].quantile(0.25)
lower_limit = data['relapse_time'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['relapse_time'].quantile(0.75) + (IQR * 1.5)

from feature_engine.outliers import Winsorizer

winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['relapse_time'])
data_t = winsor.fit_transform(data[['relapse_time']])
sns.boxplot(data_t.relapse_time);plt.title('relapse_time');plt.show()

IQR = data['HPE'].quantile(0.75) - data['HPE'].quantile(0.25)
lower_limit = data['HPE'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['HPE'].quantile(0.75) + (IQR * 1.5)


winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['HPE'])
data_t = winsor.fit_transform(data[['HPE']])
sns.boxplot(data_t.HPE);plt.title('HPE');plt.show()

## Correlation

data.corr()
sns.pairplot(data.iloc[:,:])

plt.figure(figsize = (20,20) );plt.style.use("default")
sns.heatmap(data.corr(),annot = True)

sns.countplot(x = "Age", y = "relapse", data = data)
sns.countplot(x= 'HPE',hue = 'relapse',data = data)  
sns.countplot(x="Stage" ,hue = "relapse", data = data)  
sns.countplot(x = "TumorSize", hue = "relapse", data =data)


data['relapse'].unique()
data['relapse'].value_counts()
colnames = list(data.columns)

predictors = colnames[:13]
target = colnames[7]

# Splitting data into training and testing data set

from sklearn.model_selection import train_test_split

train, test = train_test_split(data, test_size = 0.3,random_state =42)

from sklearn.tree import DecisionTreeClassifier as DT

model = DT(criterion = 'entropy',max_depth=4,max_features=(5))

model.fit(train[predictors], train[target])

from sklearn import tree

import matplotlib.pylab as plt

plt.figure(figsize=(10,15))

tree.plot_tree(model,filled=True)

# Prediction on Test Data

preds = model.predict(test[predictors])
pd.crosstab(test[target], preds, rownames=['Actual'], colnames=['Predictions'])

np.mean(preds == test[target]) # Test Data Accuracy 

# Prediction on Train Data
preds = model.predict(train[predictors])
pd.crosstab(train[target], preds, rownames = ['Actual'], colnames = ['Predictions'])

np.mean(preds == train[target]) # Train Data Accuracy

########## Bagging classifier

X = data.drop("relapse", axis = 1)

y = data["relapse"]

X_test,X_train,y_test,y_train = train_test_split(X,y, test_size = 0.3)

from sklearn import tree

clftree = tree.DecisionTreeClassifier()

from sklearn.ensemble import BaggingClassifier

bag_clf = BaggingClassifier(base_estimator = clftree ,n_estimators = 5, n_jobs = 1,random_state = 4)

bag_clf.fit(X_train, y_train)

# Evaluation on Testing Data
confusion_matrix(y_test, bag_clf.predict(X_test))
accuracy_score(y_test, bag_clf.predict(X_test))

# Evaluation on Training Data
confusion_matrix(y_train, bag_clf.predict(X_train))
accuracy_score(y_train, bag_clf.predict(X_train))

#### Ada boost classifier

from sklearn.ensemble import AdaBoostClassifier

ada_clf = AdaBoostClassifier(learning_rate = 0.02, n_estimators = 500)

ada_clf.fit(X_train, y_train)

from sklearn.metrics import accuracy_score, confusion_matrix

# Evaluation on Testing Data
confusion_matrix(y_test, ada_clf.predict(X_test))
accuracy_score(y_test, ada_clf.predict(X_test))

# Evaluation on Training Data
confusion_matrix(y_train, ada_clf.predict(X_train))
accuracy_score(y_train, ada_clf.predict(X_train))

### Gradient Boosting classification

from sklearn.ensemble import GradientBoostingClassifier

boost_clf = GradientBoostingClassifier()

boost_clf.fit(X_train, y_train)

confusion_matrix(y_test, boost_clf.predict(X_test))
accuracy_score(y_test, boost_clf.predict(X_test))

# Hyper parameters

boost_clf2 = GradientBoostingClassifier(learning_rate = 0.02, n_estimators = 100, max_depth = 1)
boost_clf2.fit(X_train, y_train)

# Evaluation on Testing Data
confusion_matrix(y_test, boost_clf2.predict(X_test))
accuracy_score(y_test, boost_clf2.predict(X_test))

# Evaluation on Training Data
confusion_matrix(y_train, boost_clf2.predict(X_train))
accuracy_score(y_train, boost_clf2.predict(X_train))

import xgboost as xgb

xgb_clf = xgb.XGBClassifier(max_depths = 6, n_estimators = 100, learning_rate = 0.3, n_jobs = 1)

xgb_clf.fit(X_train, y_train)

# Evaluation on Testing Data
confusion_matrix(y_test, xgb_clf.predict(X_test))
accuracy_score(y_test, xgb_clf.predict(X_test))

# Evaluation on training data
confusion_matrix(y_train, xgb_clf.predict(X_train))
accuracy_score(y_train, xgb_clf.predict(X_train))

xgb.plot_importance(xgb_clf)

xgb_clf = xgb.XGBClassifier(n_estimators = 500, learning_rate = 0.1, random_state = 42)

param_test1 = {'max_depth': range(3,10,2), 'gamma': [0.1, 0.2, 0.3],
               'subsample': [0.8, 0.9], 'colsample_bytree': [0.8, 0,9],
               'rag_alpha': [1e-2, 0.1, 1]}

# Grid Search

from sklearn.model_selection import GridSearchCV

grid_search = GridSearchCV(xgb_clf, param_test1, n_jobs = -1, cv = 5, scoring = 'accuracy')

grid_search.fit(X_train, y_train)

cv_xg_clf = grid_search.best_estimator_

# Evaluation on Testing Data with model with hyperparameter
accuracy_score(y_test, cv_xg_clf.predict(X_test))
grid_search.best_params_

################## Randomforest classification#############

from sklearn.ensemble import RandomForestClassifier

rf_clf = RandomForestClassifier(n_estimators=500, n_jobs=1, random_state=42)

rf_clf.fit(X_train, y_train)

from sklearn.metrics import accuracy_score, confusion_matrix

confusion_matrix(y_test, rf_clf.predict(X_test))
accuracy_score(y_test, rf_clf.predict(X_test))


rf_clf_grid = RandomForestClassifier(n_estimators=500, n_jobs=1, random_state=42)

param_grid = {"max_features": [4, 5, 6, 7, 8, 9, 10], "min_samples_split": [2, 3, 10]}

grid_search = GridSearchCV(rf_clf_grid, param_grid, n_jobs = -1, cv = 5, scoring = 'accuracy')

grid_search.fit(X_train, y_train)

grid_search.best_params_

cv_rf_clf_grid = grid_search.best_estimator_


confusion_matrix(y_train, cv_rf_clf_grid.predict(X_train))
accuracy_score(y_train, cv_rf_clf_grid.predict(X_train))

#################### Logistic Regression #################

from sklearn import metrics
from sklearn.metrics import roc_curve, auc
from sklearn.metrics import classification_report

import statsmodels.formula.api as smf

logit_model = smf.logit ('relapse ~ HPE + Stage + TumorSize + Surgery + surgerylevel + relapse_time + Chemogiveninitially + Treatmentgivenonrelapse + Outcome_time', data = data).fit(method ="bfgs")
logit_model.summary()
logit_model.summary2()

predict = logit_model.predict(data.iloc[:, 1:])

from sklearn import metrics

fpr,tpr,thresholds = roc_curve(data.relapse, predict)
optimal_idx  = np.argmax(tpr-fpr)
optimal_threshold = thresholds[optimal_idx]
optimal_threshold

import pylab as pl

i = np.arange(len(tpr))
roc = pd.DataFrame({'fpr' : pd.Series(fpr, index=i),'tpr' : pd.Series(tpr, index = i), '1-fpr' : pd.Series(1-fpr, index = i), 'tf' : pd.Series(tpr - (1-fpr), index = i), 'thresholds' : pd.Series(thresholds, index = i)})
roc.iloc[(roc.tf-0).abs().argsort()[:1]]

# Plot tpr vs 1-fpr
fig, ax = pl.subplots()
pl.plot(roc['tpr'], color = 'red');pl.plot(roc['1-fpr'], color = 'blue');pl.xlabel('1-False Positive Rate');pl.ylabel('True Positive Rate');pl.title('Receiver operating characteristic')
ax.set_xticklabels([])

roc_auc = auc(fpr, tpr)
print("Area under the ROC curve : %f" % roc_auc)

data["predict"] = np.zeros(34)

data.loc[predict > optimal_threshold, "predict"] = 0

#classification report
classification = classification_report(data["predict"],data["relapse"])
classification

### Spliting the data into train and test data

from sklearn.model_selection import train_test_split

train_data,test_data = train_test_split(data,test_size = 0.3)

logit_model = smf.logit('relapse ~ HPE + Stage + TumorSize + Surgery + surgerylevel + relapse_time + Chemogiveninitially + Treatmentgivenonrelapse + Outcome_time', data = train_data).fit(method = "bfgs")
logit_model.summary()
logit_model.summary2()

#prediction on test data set

test_predict = logit_model.predict(test_data)

test_data["test_predict"] = np.zeros(11)

test_data.loc[test_predict > optimal_threshold, "test_predict"] = 1

#### Confusin matrix
confusion_matrix = pd.crosstab(test_data.test_predict,test_data["relapse"])
confusion_matrix

accuracy_test = (5+4)/(11)
accuracy_test

#### classification report

classification_test = classification_report(test_data["test_predict"], test_data["relapse"])
classification_test

### Roc Curve And AUC

fpr,tpr, thershold = metrics.roc_curve(test_data["relapse"], test_predict)

### plot Of ROC

plt.plot(fpr, tpr);plt.xlabel("False Positive Rate");plt.ylabel("True Positive Rate")

roc_auc_test = metrics.auc(fpr, tpr)
roc_auc_test

###prediction on train data

train_predict = logit_model.predict(train_data.iloc[:, 1:])

train_data["train_predict"] = np.zeros(23)

train_data.loc[train_predict > optimal_threshold, "train_predict"] = 1

confusion_matrix  = pd.crosstab(train_data.train_predict, train_data["relapse"])
confusion_matrix

accuracy_train = (17+6)/(23)
print(accuracy_train)

########### KNN model######

from sklearn.neighbors import KNeighborsClassifier

knn = KNeighborsClassifier()
knn.fit(X_train, y_train)

pred = knn.predict(X_test)
pred

# Evaluate the model
from sklearn.metrics import accuracy_score

pd.crosstab(y_test, pred, rownames = ['Actual'], colnames= ['Predictions']) 
print(accuracy_score(y_test, pred))

# error on train data
pred_train = knn.predict(X_train)

pd.crosstab(y_train, pred_train, rownames=['Actual'], colnames = ['Predictions']) 
print(accuracy_score(y_train, pred_train))


############## final model ##########

######## Decision Tree classifier

data = data.drop(["Survival ","event"], axis = 1)

X = data.drop(["relapse"], axis = 1)
y = data["relapse"]

# Splitting data into training and testing data set

from sklearn.model_selection import train_test_split

X_train, X_test,y_train,y_test = train_test_split(X,y, test_size = 0.3,random_state = 42)

from sklearn.tree import DecisionTreeClassifier as DT

classifier = DT(criterion = 'entropy',max_depth=4,max_features=(5))

classifier.fit(X_train,y_train)

#### Prediction

ts_predict = classifier.predict(X_test)
tr_predict = classifier.predict(X_train)

print("Traininng Accuracy : ", accuracy_score(y_train,tr_predict))
print("Testing Accuracy : ", accuracy_score(y_test,ts_predict))

from sklearn import tree

import matplotlib.pylab as plt

plt.figure(figsize=(10,15))

tree.plot_tree(classifier,filled=True)

data_importance = pd.DataFrame({"Features" : X.columns,"Impotances":classifier.feature_importances_})
data_importance

import pickle

with open("classifier.pickle","wb") as f:
    pickle.dump(classifier,f)
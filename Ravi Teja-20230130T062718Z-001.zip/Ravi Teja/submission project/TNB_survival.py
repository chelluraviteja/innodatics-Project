##################  Survival Analytics ##########################

#pip install lifelines
import lifelines
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder
import numpy as np

### load the dataset

data = pd.read_excel("C:/Users/DELL/Desktop/DS_Project_Team_60/TNBC_survival.xlsx")

data["Outcome_time"].describe() 


### 1. Exploratory Data Analysis

data.describe()

#### Business Decision Movement 

data.mean()
data.median()
data.std()
data.var()
data.skew()
data.kurt()

#### Data Visualization

### Histogram

data.hist(figsize = (10,10))

#### Boxplot

data.boxplot(figsize = (10,10))

##### DATA Preprocessing

#### Type Casting

data.dtypes

#### Identifying the duplicates

duplicate = data.duplicated()
sum(duplicate)

#### Missing Values

data.isna()
data.isna().sum()

### For replacing the missing values here using the mean imputation or fillna() 

from sklearn.impute import SimpleImputer

# Mean Imputer 

mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
data["relapse_time"] = pd.DataFrame(mean_imputer.fit_transform(data[["relapse_time"]]))
data["relapse_time"].isna().sum()

mean_imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
data["Outcome_time"] = pd.DataFrame(mean_imputer.fit_transform(data[["Outcome_time"]]))
data["Outcome_time"].isna().sum()

lb = LabelEncoder()

data ["HPE"] = lb.fit_transform(data["HPE"])
data ["Stage"] = lb.fit_transform(data["Stage"])
data ["Surgery"] = lb.fit_transform(data["Surgery"])
data ["Treatmentgivenonrelapse"] = lb.fit_transform(data["Treatmentgivenonrelapse"])
data ["TumorSize"] = lb.fit_transform(data["TumorSize"])
data ["Chemogiveninitially"] = lb.fit_transform(data["Chemogiveninitially"])
data["Survival "] = lb.fit_transform(data["Survival "])

### Outlier Treatment ( here the relapse _time column has the outliers can removed by using the winsorization technique )

IQR = data['relapse_time'].quantile(0.75) - data['relapse_time'].quantile(0.25)
lower_limit = data['relapse_time'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['relapse_time'].quantile(0.75) + (IQR * 1.5)

from feature_engine.outliers import Winsorizer

winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['relapse_time'])
data_t = winsor.fit_transform(data[['relapse_time']])
sns.boxplot(data_t.relapse_time);plt.title('relapse_time');plt.show()

IQR = data['HPE'].quantile(0.75) - data['HPE'].quantile(0.25)
lower_limit = data['HPE'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['HPE'].quantile(0.75) + (IQR * 1.5)


winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['HPE'])
data_t = winsor.fit_transform(data[['HPE']])
sns.boxplot(data_t.HPE);plt.title('HPE');plt.show()

data.fillna(0)

### Outcome_time is referring to time

T = data.Outcome_time
#Importing the KaplanMeierFitter model to fit the survival analysis

from lifelines import KaplanMeierFitter

# Initiating the KaplanMeierFitter model
kmf = KaplanMeierFitter()

# Over Multiple groups 
# For each group, here group is event
data.event.value_counts()

# Fitting KaplanMeierFitter model on Time and Events for death 
kmf.fit(T,data.event)

# Time-line estimations plot 
kmf.plot()


# Applying KaplanMeierFitter model on Time and Events for the group "1"
kmf.fit(T[data.event==1], data.event[data.event==1], label='1')
ax = kmf.plot()

# Applying KaplanMeierFitter model on Time and Events for the group "0"
kmf.fit(T[data.event==0], data.event[data.event == 0], label='0')
ax = kmf.plot(ax=ax)

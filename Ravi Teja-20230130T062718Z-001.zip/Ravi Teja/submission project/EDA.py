import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
import seaborn as sns
data = pd.read_excel("C:/Users/DELL/Desktop/DATA 70 pts AR + TNBC.xlsx")
data.describe()

#### Exploratary Data Analysis
## 1.First moment business decision

data.mean()
data.median()

## 2.Second moment business decision

data.std()
data.var()

## 3.Third moment business decision

data.skew()

## 4.Fourth moment business decision

data.kurt()

### Data Visulization

data.hist(figsize = (12,12))
data.boxplot(figsize = (12,12))

#Normally distribution
import pylab
stats.probplot(data.age,dist="norm",plot=pylab);plt.title("age")
stats.probplot(data.Nodalstatus,dist="norm",plot=pylab);plt.title("Nodalstatus")

from sklearn.preprocessing import LabelEncoder
lb = LabelEncoder()

data["Menaupausalstatus"] = lb.fit_transform(data["Menaupausalstatus"])
data["Menaupausalstatus.1"] = lb.fit_transform(data["Menaupausalstatus.1"])
data["Stage"] = lb.fit_transform(data["Stage"])
data["Grade"] = lb.fit_transform(data["Grade"])
data["LVI"] = lb.fit_transform(data["LVI"])
data["Margins"] = lb.fit_transform(data["Margins"])
data["Chemo"] = lb.fit_transform(data["Chemo"])
data["AR"] = lb.fit_transform(data["AR"])
data["AR1"] = lb.fit_transform(data["AR1"])
data["AGE1"] = lb.fit_transform(data["AGE1"])
data["NS1"] = lb.fit_transform(data["NS1"])

#### After labelEncoding (The outlier treatment)

data.boxplot(figsize = (10,5))

IQR = data['age'].quantile(0.75) - data['age'].quantile(0.25)
lower_limit = data['age'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['age'].quantile(0.75) + (IQR * 1.5)

from feature_engine.outliers import Winsorizer

winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['age'])
data_t = winsor.fit_transform(data[['age']])
sns.boxplot(data_t.age);plt.title('age');plt.show()

IQR = data['Nodalstatus'].quantile(0.75) - data['Nodalstatus'].quantile(0.25)
lower_limit = data['Nodalstatus'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['Nodalstatus'].quantile(0.75) + (IQR * 1.5)

winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['Nodalstatus'])
data_t = winsor.fit_transform(data[['Nodalstatus']])
sns.boxplot(data_t.Nodalstatus);plt.title('Nodalstatus');plt.show()

IQR = data['LVI'].quantile(0.75) - data['LVI'].quantile(0.25)
lower_limit = data['LVI'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['LVI'].quantile(0.75) + (IQR * 1.5)

winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['LVI'])
data_t = winsor.fit_transform(data[['LVI']])
sns.boxplot(data_t.LVI);plt.title('LVI');plt.show()

IQR = data['Margins'].quantile(0.75) - data['Margins'].quantile(0.25)
lower_limit = data['Margins'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['Margins'].quantile(0.75) + (IQR * 1.5)

winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['Margins'])
data_t = winsor.fit_transform(data[['Margins']])
sns.boxplot(data_t.Margins);plt.title('Margins');plt.show()

IQR = data['AR'].quantile(0.75) - data['AR'].quantile(0.25)
lower_limit = data['AR'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['AR'].quantile(0.75) + (IQR * 1.5)


winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['AR'])
data_t = winsor.fit_transform(data[['AR']])
sns.boxplot(data_t.AR);plt.title('AR');plt.show()

IQR = data['AR1'].quantile(0.75) - data['AR1'].quantile(0.25)
lower_limit = data['AR1'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['AR1'].quantile(0.75) + (IQR * 1.5)

from feature_engine.outliers import Winsorizer

winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['AR1'])
data_t = winsor.fit_transform(data[['AR1']])
sns.boxplot(data_t.AR1);plt.title('AR1');plt.show()

IQR = data['NS1'].quantile(0.75) - data['NS1'].quantile(0.25)
lower_limit = data['NS1'].quantile(0.25) - (IQR * 1.5)
upper_limit = data['NS1'].quantile(0.75) + (IQR * 1.5)


winsor = Winsorizer(capping_method='iqr', # choose  IQR rule boundaries or gaussian for mean and std
                          tail='both', # cap left, right or both tails 
                          fold=1.5,
                          variables=['NS1'])
data_t = winsor.fit_transform(data[['NS1']])
sns.boxplot(data_t.NS1);plt.title('NS1');plt.show()

##### missing values

data.isna()
data.isna().sum()

##### Identifying Duplicates

duplicate  = data.duplicated()

sum(duplicate)

### Zero variance

data.var()


data.corr()
sns.heatmap(data.corr(),annot = True)
sns.pairplot(data.iloc[:,:])

import pickle
import pandas as pd
import streamlit as st
import numpy as np

classifier  = pickle.load(open("classifier.pkl","rb"))
df = pickle.load(open("data_f.pickle","rb"))

st.title("Survial and Relapse Analytics In TNBC Cases")
html_temp = """
    <div style="background-color:tomato;padding:10px">
    <h2 style="color:white;text-align:center;"> Survival and Relapse analysis in TNBC Cases </h2>
    </div>
    """
st.markdown(html_temp,unsafe_allow_html=True)
Age = st.selectbox("Age",df["Age"].unique())
HPE = st.selectbox("HPE",df["HPE"].unique())
Stage = st.selectbox("Stage",df["Stage"].unique())
TumorSize = st.selectbox("TumorSize",df["TumorSize"].unique())
Surgery = st.selectbox("Surgery",df["Surgery"].unique())
relapse = st.selectbox("relapse",df["relapse"].unique())
surgerylevel = st.selectbox("surgerylevel",df["surgerylevel"].unique())
Chemogiveninitially = st.selectbox("Chemogiveninitially",df["Chemogiveninitially"].unique())
relapse_time =st.selectbox("relapse_time",df["relapse_time"].unique())
Outcome_time = st.selectbox("Outcome_time",df["Outcome_time"].unique())
Treatmentgivenonrelapse = st.selectbox("Treatmentgivenonrelapse",df["Treatmentgivenonrelapse"].unique())

if st.button("Predict"):
    if relapse == 1:
        print("Possibiltiy of reoccurance of cancer")
    else:
        print("No Possibiltiy of reoccurance of cancer")